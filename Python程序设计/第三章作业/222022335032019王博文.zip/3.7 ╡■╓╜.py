thickness=0.00008
flag=0
while thickness<8848.13 :
    flag=flag+1
    thickness=thickness*2
print(flag)